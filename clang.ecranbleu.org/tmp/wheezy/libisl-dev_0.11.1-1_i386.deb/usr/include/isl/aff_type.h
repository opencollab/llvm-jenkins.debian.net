#ifndef ISL_AFF_TYPE_H
#define ISL_AFF_TYPE_H

struct isl_aff;
typedef struct isl_aff isl_aff;

struct isl_pw_aff;
typedef struct isl_pw_aff isl_pw_aff;

struct isl_multi_aff;
typedef struct isl_multi_aff isl_multi_aff;

struct isl_pw_multi_aff;
typedef struct isl_pw_multi_aff isl_pw_multi_aff;

struct isl_union_pw_multi_aff;
typedef struct isl_union_pw_multi_aff isl_union_pw_multi_aff;

struct isl_multi_pw_aff;
typedef struct isl_multi_pw_aff isl_multi_pw_aff;

#endif
