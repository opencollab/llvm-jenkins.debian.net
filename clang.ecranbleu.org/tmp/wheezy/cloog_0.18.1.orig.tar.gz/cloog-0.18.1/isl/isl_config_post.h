#ifndef HAVE___ATTRIBUTE__
#define __attribute__(x)
#endif
