for (int c0 = 0; c0 <= 10; c0 += 1) {
  if (c0 >= 1)
    b(c0 - 1);
  if (c0 <= 9)
    a(c0);
}
