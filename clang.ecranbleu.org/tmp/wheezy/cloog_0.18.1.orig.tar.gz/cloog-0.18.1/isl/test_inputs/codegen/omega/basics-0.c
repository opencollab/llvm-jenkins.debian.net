{
  for (int c0 = 5; c0 <= 8; c0 += 1)
    s0(c0);
  for (int c0 = 10; c0 <= 16; c0 += 2)
    s0(c0);
  for (int c0 = 20; c0 <= 25; c0 += 1)
    s0(c0);
}
