{
  for (int c1 = 0; c1 <= M; c1 += 1)
    S1(c1);
  for (int c1 = 1; c1 <= M; c1 += 1)
    S2(c1);
  for (int c1 = 0; c1 <= M; c1 += 1)
    S3(c1);
}
