for (int c0 = max(exprVar2 + 8 * floord(-exprVar2 + exprVar1 - 1, 8) + 9, exprVar2 + 1); c0 <= 16; c0 += 8)
  s0(c0);
